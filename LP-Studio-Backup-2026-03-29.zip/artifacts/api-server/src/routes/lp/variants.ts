import { Router } from "express";
import { eq, and } from "drizzle-orm";
import { db } from "@workspace/db";
import { lpVariantsTable } from "@workspace/db";
import {
  CreateVariantParams,
  CreateVariantBody,
  UpdateVariantParams,
  DeleteVariantParams,
  ListVariantsParams,
} from "@workspace/api-zod";

const router = Router();

router.get("/lp/tests/:testId/variants", async (req, res): Promise<void> => {
  const params = ListVariantsParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const variants = await db
    .select()
    .from(lpVariantsTable)
    .where(eq(lpVariantsTable.testId, params.data.testId))
    .orderBy(lpVariantsTable.createdAt);
  res.json(variants);
});

router.post("/lp/tests/:testId/variants", async (req, res): Promise<void> => {
  const params = CreateVariantParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const parsed = CreateVariantBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: parsed.error.message });
    return;
  }
  const body = req.body as Record<string, unknown>;
  const builderPageId =
    typeof body.builderPageId === "number" && Number.isFinite(body.builderPageId) && body.builderPageId > 0
      ? Math.floor(body.builderPageId)
      : null;
  // Always read config from req.body to preserve extended JSONB fields
  // (trustBar, benefits, testimonials, templateId, etc.) beyond the schema.
  const rawConfig: Record<string, unknown> =
    body.config !== undefined && typeof body.config === "object" && body.config !== null && !Array.isArray(body.config)
      ? (body.config as Record<string, unknown>)
      : {};
  const testedBlockId =
    typeof body.testedBlockId === "string" && body.testedBlockId.length > 0
      ? body.testedBlockId
      : null;
  const blockOverrides: Record<string, unknown> =
    body.blockOverrides !== undefined && typeof body.blockOverrides === "object" && body.blockOverrides !== null && !Array.isArray(body.blockOverrides)
      ? (body.blockOverrides as Record<string, unknown>)
      : {};
  const [variant] = await db.insert(lpVariantsTable).values({
    testId: params.data.testId,
    name: parsed.data.name,
    isControl: parsed.data.isControl ?? false,
    trafficWeight: parsed.data.trafficWeight,
    config: rawConfig,
    builderPageId,
    testedBlockId,
    blockOverrides,
  }).returning();
  res.status(201).json(variant);
});

router.put("/lp/tests/:testId/variants/:variantId", async (req, res): Promise<void> => {
  const params = UpdateVariantParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }

  const body = req.body as Record<string, unknown>;

  const updateData: Record<string, unknown> = {};
  if (typeof body.name === "string" && body.name.length > 0) updateData.name = body.name;
  if (typeof body.trafficWeight === "number") updateData.trafficWeight = body.trafficWeight;
  if (typeof body.isControl === "boolean") updateData.isControl = body.isControl;
  if ("config" in body && body.config !== undefined && typeof body.config === "object" && body.config !== null) {
    updateData.config = body.config;
  }
  if ("builderPageId" in body) {
    updateData.builderPageId =
      body.builderPageId === null ? null :
      typeof body.builderPageId === "number" ? body.builderPageId :
      null;
  }
  if ("testedBlockId" in body) {
    updateData.testedBlockId =
      typeof body.testedBlockId === "string" && body.testedBlockId.length > 0
        ? body.testedBlockId
        : null;
  }
  if ("blockOverrides" in body && body.blockOverrides !== undefined && typeof body.blockOverrides === "object" && body.blockOverrides !== null) {
    updateData.blockOverrides = body.blockOverrides;
  }

  if (Object.keys(updateData).length === 0) {
    res.status(400).json({ error: "No valid fields to update" });
    return;
  }

  const [variant] = await db
    .update(lpVariantsTable)
    .set(updateData)
    .where(and(
      eq(lpVariantsTable.id, params.data.variantId),
      eq(lpVariantsTable.testId, params.data.testId),
    ))
    .returning();
  if (!variant) {
    res.status(404).json({ error: "Variant not found" });
    return;
  }
  res.json(variant);
});

router.delete("/lp/tests/:testId/variants/:variantId", async (req, res): Promise<void> => {
  const params = DeleteVariantParams.safeParse(req.params);
  if (!params.success) {
    res.status(400).json({ error: params.error.message });
    return;
  }
  const [variant] = await db
    .delete(lpVariantsTable)
    .where(and(
      eq(lpVariantsTable.id, params.data.variantId),
      eq(lpVariantsTable.testId, params.data.testId),
    ))
    .returning();
  if (!variant) {
    res.status(404).json({ error: "Variant not found" });
    return;
  }
  res.sendStatus(204);
});

export default router;
