import { useRef, useState } from "react";
import { motion, useInView } from "framer-motion";
import { createPortal } from "react-dom";
import { X, Calendar, CheckCircle2, Loader2 } from "lucide-react";
import type { DsoCtaCaptureBlockProps } from "@/lib/block-types";
import { getBgStyle } from "@/lib/bg-styles";

const DISPLAY_FONT = "'Bagoss Standard','Inter',system-ui,sans-serif";
const PFG   = "hsl(48,100%,96%)";
const AW    = "hsl(68,60%,52%)";
const MUTED = "hsla(48,100%,96%,0.50)";
const BG    = "#050e08";
const API_BASE = "/api";

interface Props {
  props: DsoCtaCaptureBlockProps;
  pageId?: number;
  variantId?: number;
}

type FormState = "idle" | "loading" | "success" | "error";

function buildChiliPiperUrl(base: string, email: string): string {
  if (!base) return "";
  try {
    const url = new URL(base);
    url.searchParams.set("email", email);
    return url.toString();
  } catch {
    const sep = base.includes("?") ? "&" : "?";
    return `${base}${sep}email=${encodeURIComponent(email)}`;
  }
}

export function BlockDsoCtaCapture({ props, pageId, variantId }: Props) {
  const {
    eyebrow       = "Get Started Today",
    headline      = "See what Dandy can\ndo for your group.",
    body          = "Join DSO leaders already running smarter, faster dental operations. Setup takes one call.",
    inputLabel    = "Work email",
    inputPlaceholder = "yourname@dsogroup.com",
    ctaLabel      = "Request a Demo",
    trust1        = "1,200+ DSO locations",
    trust2        = "No long-term contract",
    trust3        = "Live in 30 days",
    imageUrl      = "",
    imagePosition = "right",
    chilipiperUrl = "",
    successHeadline = "You're on the list!",
    successBody = "Check your inbox — we'll be in touch shortly to schedule your demo.",
  } = props;

  const sectionRef = useRef<HTMLElement>(null);
  const inView = useInView(sectionRef, { once: true, margin: "-8%" });
  const [focused, setFocused] = useState(false);
  const [email, setEmail] = useState("");
  const [formState, setFormState] = useState<FormState>("idle");
  const [errorMsg, setErrorMsg] = useState("");
  const [cpOpen, setCpOpen] = useState(false);
  const [cpUrl, setCpUrl] = useState("");

  const hasImage  = Boolean(imageUrl);
  const imgOnLeft = imagePosition === "left";
  const trusts = [trust1, trust2, trust3].filter(Boolean);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();

    const trimmed = email.trim();
    if (!trimmed || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmed)) {
      setErrorMsg("Please enter a valid work email.");
      return;
    }
    setErrorMsg("");
    setFormState("loading");

    try {
      if (pageId) {
        await fetch(`${API_BASE}/lp/leads`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            pageId,
            variantId,
            fields: { email: trimmed, source: "dso-cta-capture" },
          }),
        });
      }
    } catch {
    }

    setFormState("success");

    if (chilipiperUrl) {
      const url = buildChiliPiperUrl(chilipiperUrl, trimmed);
      setCpUrl(url);
      setCpOpen(true);
    }
  }

  const isLoading = formState === "loading";
  const isSuccess = formState === "success";

  return (
    <section
      ref={sectionRef}
      style={{ position: "relative", overflow: "hidden", minHeight: "80vh", display: "flex", alignItems: "stretch", ...getBgStyle("dandy-green") }}
    >
      {/* Atmospheric lime radial glow */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none",
        background: imgOnLeft
          ? "radial-gradient(ellipse 60% 70% at 80% 50%, rgba(60,90,10,0.18) 0%, transparent 70%)"
          : "radial-gradient(ellipse 60% 70% at 20% 50%, rgba(60,90,10,0.18) 0%, transparent 70%)",
      }} />

      {/* Film grain */}
      <div style={{
        position: "absolute", inset: 0, pointerEvents: "none", opacity: 0.035,
        backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E\")",
        backgroundRepeat: "repeat", backgroundSize: "256px 256px",
      }} />

      {/* Full-bleed image column */}
      {hasImage && (
        <div style={{
          position: "absolute",
          left:  imgOnLeft ? 0 : "50%",
          right: imgOnLeft ? "50%" : 0,
          top: 0, bottom: 0,
          overflow: "hidden", zIndex: 1,
        }}>
          <motion.img
            src={imageUrl}
            alt=""
            animate={{ scale: [1.06, 1.10, 1.07, 1.06], x: [0, 8, -6, 0], y: [0, -10, 7, 0] }}
            transition={{ duration: 24, repeat: Infinity, ease: "easeInOut" }}
            style={{ width: "100%", height: "100%", objectFit: "cover", objectPosition: "center", display: "block" }}
          />
          <div style={{
            position: "absolute", inset: 0,
            background: imgOnLeft
              ? `linear-gradient(to right, transparent 52%, ${BG} 100%)`
              : `linear-gradient(to left,  transparent 52%, ${BG} 100%)`,
          }} />
          <div style={{
            position: "absolute", inset: 0,
            background: `linear-gradient(to bottom, ${BG} 0%, transparent 10%, transparent 90%, ${BG} 100%)`,
          }} />
        </div>
      )}

      {/* Content grid */}
      <div
        className="dcc-grid"
        style={{
          position: "relative", zIndex: 2,
          maxWidth: 1200, margin: "0 auto",
          padding: "8rem 2.5rem", width: "100%",
          display: "grid",
          gridTemplateColumns: hasImage ? "1fr 1fr" : "1fr",
          alignItems: "center",
          gap: "5rem",
        }}
      >
        {hasImage && imgOnLeft && <div />}

        <motion.div
          initial={{ opacity: 0, x: hasImage ? (imgOnLeft ? 32 : -32) : 0, y: hasImage ? 0 : 20 }}
          animate={inView ? { opacity: 1, x: 0, y: 0 } : {}}
          transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        >
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 8 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.45 }}
            style={{ display: "flex", alignItems: "center", gap: "0.6rem", marginBottom: "2rem" }}
          >
            <span style={{
              display: "inline-block", width: 7, height: 7, borderRadius: "50%",
              background: AW, boxShadow: "0 0 0 3px rgba(199,231,56,0.18)",
              flexShrink: 0,
            }} />
            <p style={{ fontSize: 11, fontWeight: 700, letterSpacing: "0.18em", textTransform: "uppercase", color: AW, margin: 0 }}>
              {eyebrow}
            </p>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 24 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1, ease: [0.16, 1, 0.3, 1] }}
            style={{
              fontFamily: DISPLAY_FONT,
              fontSize: "clamp(2.25rem, 5vw, 4.5rem)",
              fontWeight: 800, color: PFG,
              letterSpacing: "-0.045em", lineHeight: 0.95,
              marginBottom: "1.5rem", whiteSpace: "pre-line",
            }}
          >
            {headline}
          </motion.h2>

          {/* Body */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={inView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.6, delay: 0.2 }}
            style={{ fontSize: "1.0625rem", lineHeight: 1.68, color: MUTED, maxWidth: 420, marginBottom: "2.5rem" }}
          >
            {body}
          </motion.p>

          {/* ── Success state ── */}
          {isSuccess ? (
            <motion.div
              initial={{ opacity: 0, y: 12, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
              style={{
                display: "flex",
                flexDirection: "column",
                gap: "0.625rem",
                maxWidth: 480,
                background: "rgba(199,231,56,0.07)",
                border: "1px solid rgba(199,231,56,0.22)",
                borderRadius: "1rem",
                padding: "1.25rem 1.5rem",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "0.6rem" }}>
                <CheckCircle2 style={{ width: 18, height: 18, color: AW, flexShrink: 0 }} />
                <span style={{ fontFamily: DISPLAY_FONT, fontWeight: 700, fontSize: "1rem", color: PFG }}>{successHeadline}</span>
              </div>
              <p style={{ fontSize: "0.875rem", color: MUTED, margin: 0, lineHeight: 1.6 }}>{successBody}</p>
              {chilipiperUrl && (
                <button
                  type="button"
                  onClick={() => { setCpUrl(buildChiliPiperUrl(chilipiperUrl, email.trim())); setCpOpen(true); }}
                  style={{
                    alignSelf: "flex-start",
                    marginTop: "0.25rem",
                    background: AW, color: BG,
                    border: "none", borderRadius: 999,
                    padding: "9px 20px",
                    fontWeight: 700, fontSize: "0.8125rem",
                    cursor: "pointer", fontFamily: DISPLAY_FONT,
                    display: "flex", alignItems: "center", gap: "0.4rem",
                  }}
                >
                  <Calendar style={{ width: 13, height: 13 }} />
                  Open scheduler
                </button>
              )}
            </motion.div>
          ) : (
            <>
              {/* Input label */}
              {inputLabel && (
                <p style={{ fontSize: "0.6875rem", fontWeight: 700, letterSpacing: "0.12em", textTransform: "uppercase", color: "rgba(199,231,56,0.6)", marginBottom: "0.65rem" }}>
                  {inputLabel}
                </p>
              )}

              {/* Pill input + CTA */}
              <motion.form
                onSubmit={handleSubmit}
                noValidate
                initial={{ opacity: 0, y: 12 }}
                animate={inView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.3 }}
                style={{
                  display: "flex",
                  alignItems: "center",
                  background: "rgba(255,255,255,0.04)",
                  border: `1px solid ${focused ? "rgba(199,231,56,0.5)" : errorMsg ? "rgba(239,68,68,0.5)" : "rgba(199,231,56,0.2)"}`,
                  borderRadius: 999,
                  padding: "5px 5px 5px 22px",
                  gap: 8,
                  backdropFilter: "blur(12px)",
                  boxShadow: focused ? "0 0 0 3px rgba(199,231,56,0.08), 0 0 24px rgba(199,231,56,0.06)" : "none",
                  transition: "border-color 0.2s, box-shadow 0.2s",
                  maxWidth: 480,
                }}
              >
                <input
                  type="email"
                  value={email}
                  onChange={e => { setEmail(e.target.value); if (errorMsg) setErrorMsg(""); }}
                  placeholder={inputPlaceholder}
                  onFocus={() => setFocused(true)}
                  onBlur={() => setFocused(false)}
                  disabled={isLoading}
                  style={{
                    flex: 1, minWidth: 0,
                    background: "none", border: "none", outline: "none",
                    color: PFG, fontSize: "0.9375rem",
                    fontFamily: "inherit",
                    opacity: isLoading ? 0.5 : 1,
                  }}
                />
                <button
                  type="submit"
                  disabled={isLoading}
                  style={{
                    background: AW,
                    color: "#050e08",
                    border: "none", borderRadius: 999,
                    padding: "13px 26px",
                    fontWeight: 800, fontSize: "0.875rem",
                    cursor: isLoading ? "not-allowed" : "pointer",
                    whiteSpace: "nowrap",
                    fontFamily: DISPLAY_FONT,
                    letterSpacing: "-0.01em",
                    flexShrink: 0,
                    opacity: isLoading ? 0.75 : 1,
                    transition: "opacity 0.15s",
                    display: "flex", alignItems: "center", gap: "0.4rem",
                  }}
                  onMouseEnter={e => !isLoading && (e.currentTarget.style.opacity = "0.88")}
                  onMouseLeave={e => !isLoading && (e.currentTarget.style.opacity = "1")}
                >
                  {isLoading && <Loader2 style={{ width: 14, height: 14, animation: "spin 1s linear infinite" }} />}
                  {ctaLabel}
                </button>
              </motion.form>

              {/* Error message */}
              {errorMsg && (
                <p style={{ fontSize: "0.75rem", color: "rgba(239,68,68,0.85)", marginTop: "0.5rem", marginLeft: "1rem" }}>
                  {errorMsg}
                </p>
              )}
            </>
          )}

          {/* Trust strip */}
          {trusts.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={inView ? { opacity: 1 } : {}}
              transition={{ duration: 0.5, delay: 0.45 }}
              style={{
                display: "flex", flexWrap: "wrap", gap: "1.25rem 2rem",
                marginTop: "1.75rem", alignItems: "center",
              }}
            >
              {trusts.map((t, i) => (
                <span key={i} style={{ display: "flex", alignItems: "center", gap: "0.45rem" }}>
                  <svg width="13" height="13" viewBox="0 0 13 13" fill="none">
                    <circle cx="6.5" cy="6.5" r="6" stroke="rgba(199,231,56,0.35)" strokeWidth="1" />
                    <path d="M3.5 6.5l2 2 4-4" stroke={AW} strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" />
                  </svg>
                  <span style={{ fontSize: "0.8125rem", color: MUTED, fontWeight: 500 }}>{t}</span>
                </span>
              ))}
            </motion.div>
          )}
        </motion.div>

        {hasImage && !imgOnLeft && <div />}
      </div>

      <style>{`
        @media (max-width: 768px) {
          .dcc-grid { grid-template-columns: 1fr !important; gap: 2rem !important; }
        }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>

      {/* ── Chili Piper Modal ── */}
      {cpOpen && createPortal(
        <div
          style={{
            position: "fixed", inset: 0,
            background: "rgba(0,0,0,0.72)",
            backdropFilter: "blur(4px)",
            zIndex: 9999,
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: "1.5rem",
          }}
          onClick={e => { if (e.target === e.currentTarget) setCpOpen(false); }}
        >
          <div
            style={{
              position: "relative", width: "100%",
              maxWidth: 880, height: "min(90vh, 720px)",
              background: "#fff", borderRadius: "1.25rem",
              overflow: "hidden",
              boxShadow: "0 30px 70px rgba(0,0,0,0.45)",
              display: "flex", flexDirection: "column",
            }}
          >
            <div
              style={{
                display: "flex", alignItems: "center",
                justifyContent: "space-between",
                padding: "0.875rem 1.25rem",
                borderBottom: "1px solid #e5e7eb",
                flexShrink: 0,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <Calendar style={{ width: 16, height: 16, color: "#003A30" }} />
                <span style={{ fontSize: "0.875rem", fontWeight: 600, color: "#003A30", fontFamily: "'Inter',system-ui,sans-serif" }}>
                  Schedule a Meeting
                </span>
              </div>
              <button
                onClick={() => setCpOpen(false)}
                style={{
                  background: "none", border: "none", cursor: "pointer",
                  padding: "0.25rem", borderRadius: "0.375rem",
                  display: "flex", alignItems: "center", justifyContent: "center",
                  color: "#6b7280", transition: "background 0.15s",
                }}
                onMouseEnter={e => (e.currentTarget.style.background = "#f3f4f6")}
                onMouseLeave={e => (e.currentTarget.style.background = "none")}
              >
                <X style={{ width: 18, height: 18 }} />
              </button>
            </div>
            <iframe
              src={cpUrl}
              style={{ flex: 1, width: "100%", border: "none", minHeight: 0 }}
              allow="camera; microphone; clipboard-write"
              title="Schedule a Meeting"
            />
          </div>
        </div>,
        document.body
      )}
    </section>
  );
}
