import type { ZigzagFeaturesBlockProps, ZigzagFeatureRow } from "@/lib/block-types";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Plus, Trash2 } from "lucide-react";
import { ImagePicker } from "@/components/ImagePicker";
import { HEADLINE_SIZE_LABELS } from "@/lib/typography";
import { AiTextField } from "@/components/AiTextField";
import { suggestCopy } from "@/lib/copy-api";

interface Props {
  blockType: string;
  props: ZigzagFeaturesBlockProps;
  onChange: (props: ZigzagFeaturesBlockProps) => void;
  brandVoiceSet?: boolean;
}

export function ZigzagFeaturesPanel({ blockType, props, onChange, brandVoiceSet }: Props) {
  const updateRow = (i: number, key: keyof ZigzagFeatureRow, value: string) => {
    const rows = props.rows.map((r, idx) => idx === i ? { ...r, [key]: value } : r);
    onChange({ ...props, rows });
  };

  const addRow = () =>
    onChange({
      ...props,
      rows: [
        ...props.rows,
        { tag: "FEATURE", headline: "New Feature", body: "Describe this feature here.", ctaText: "Learn more", ctaUrl: "#", imageUrl: "" },
      ],
    });

  const removeRow = (i: number) =>
    onChange({ ...props, rows: props.rows.filter((_, idx) => idx !== i) });

  return (
    <div className="space-y-4">
      <div>
        <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-1.5 block">Feature Headline Size</Label>
        <Select
          value={props.headlineSize ?? "md"}
          onValueChange={v => { if (v === "sm" || v === "md" || v === "lg" || v === "xl" || v === "2xl") onChange({ ...props, headlineSize: v }); }}
        >
          <SelectTrigger className="text-sm"><SelectValue /></SelectTrigger>
          <SelectContent>
            {Object.entries(HEADLINE_SIZE_LABELS).map(([key, label]) => (
              <SelectItem key={key} value={key}>{label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>
      <Label className="text-xs font-semibold text-muted-foreground uppercase tracking-wider block">
        Feature Rows
      </Label>
      {props.rows.map((row, i) => {
        const siblingHeadlines = props.rows
          .filter((_, idx) => idx !== i)
          .slice(0, 4)
          .map(x => x.headline)
          .join(" | ");
        const siblingSnippets = props.rows
          .filter((_, idx) => idx !== i)
          .slice(0, 3)
          .map(x => `${x.headline}: ${x.body.slice(0, 60)}`)
          .join(" | ");
        return (
          <div key={i} className="border rounded-lg p-3 space-y-2">
            <div className="flex items-center justify-between mb-1">
              <span className="text-xs font-medium text-muted-foreground">
                Row {i + 1} — {i % 2 === 0 ? "Image Left" : "Image Right"}
              </span>
              <Button
                size="icon"
                variant="ghost"
                className="w-6 h-6 text-muted-foreground hover:text-red-500"
                onClick={() => removeRow(i)}
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Tag Label</Label>
              <Input
                value={row.tag}
                onChange={e => updateRow(i, "tag", e.target.value)}
                className="text-xs h-7"
                placeholder="e.g. SPEED"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Headline</Label>
              <AiTextField
                type="input"
                value={row.headline}
                onChange={v => updateRow(i, "headline", v)}
                placeholder="Feature headline"
                fieldLabel={`Row ${i + 1} Headline`}
                className="text-xs h-7"
                brandVoiceSet={brandVoiceSet}
                onSuggest={() => suggestCopy(blockType, "headline", row.headline, {
                  body: row.body,
                  tagline: siblingHeadlines,
                })}
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">Body</Label>
              <AiTextField
                type="textarea"
                value={row.body}
                onChange={v => updateRow(i, "body", v)}
                rows={3}
                fieldLabel={`Row ${i + 1} Body`}
                className="text-xs resize-none"
                brandVoiceSet={brandVoiceSet}
                onSuggest={() => suggestCopy(blockType, "body", row.body, {
                  headline: row.headline,
                  tagline: siblingSnippets,
                })}
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">CTA Text</Label>
              <Input
                value={row.ctaText}
                onChange={e => updateRow(i, "ctaText", e.target.value)}
                className="text-xs h-7"
              />
            </div>
            <div>
              <Label className="text-xs text-muted-foreground mb-1 block">CTA Action</Label>
              <Select
                value={row.ctaAction ?? "url"}
                onValueChange={v => updateRow(i, "ctaAction", v)}
              >
                <SelectTrigger className="text-xs h-7"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="url">Open URL</SelectItem>
                  <SelectItem value="chilipiper">Open Chili Piper</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {(row.ctaAction ?? "url") === "url" ? (
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">CTA URL</Label>
                <Input
                  value={row.ctaUrl}
                  onChange={e => updateRow(i, "ctaUrl", e.target.value)}
                  className="text-xs h-7"
                  placeholder="#"
                />
              </div>
            ) : (
              <div>
                <Label className="text-xs text-muted-foreground mb-1 block">Chili Piper URL</Label>
                <Input
                  value={row.chilipiperUrl ?? ""}
                  onChange={e => updateRow(i, "chilipiperUrl", e.target.value)}
                  className="text-xs h-7 font-mono"
                  placeholder="https://meetdandy.chilipiper.com/..."
                />
              </div>
            )}
            <ImagePicker
              label="Image"
              value={row.imageUrl}
              onChange={v => updateRow(i, "imageUrl", v)}
              placeholder="Paste URL or upload"
            />
          </div>
        );
      })}
      <Button
        variant="outline"
        size="sm"
        className="w-full gap-1.5 text-xs"
        onClick={addRow}
      >
        <Plus className="w-3.5 h-3.5" /> Add Row
      </Button>
    </div>
  );
}
